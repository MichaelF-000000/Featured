

//Import Declarations
import javax.swing.JFrame; 
import javax.swing.JPanel; // import javax.swing.*; can use but this imports 1 000 000 other things yo do not need
import java.awt.Color;


/**
 * Title: Basic J-Frame Assembly
 * 
 * Program Summary: 
 * The class JFrameExemplar1 is used to demo a basic GUI (Graphical user Interface) or empty JFrame, 
 * The following code is desigend to show students the keywords and sytax needed to gernerate an empty JFrame (no buttons, no text boxes, no window listeners).
 *
 * Program Element List:
 * Frames, Panels, setBounds(), .setLayout(), .getContentPane(), .setBackground(), .add(), .setVisible(), ExitOnCLose  
 *
 * @author (John Vatougios)
 * @version (Version #1)
 */
public class JFrameExemplar1
{
       
    
    // Define Frame Objects
    // By defining the objects here they become global variables, meaning they are accessible by any method wihtin this class / file
    JFrame myFrame; // Used to set up the GUI (user interface) and establish its outer bounds
    JPanel bluePanel; // Used to organize the content within the frame
    JPanel redPanel;
    JPanel yellowPanel;
    
    
    /**
     * Constructor for objects of class JFrameExemplar
     * 
     * All frames should be constructed here, not built in the main.
     * All Frames should be objects (an instance of a data type): JFrameExemplar1 runGui = new JFrameExemplar1();
     * Complex objects like Frames should be modified through methods
     * 
     */
    public JFrameExemplar1()
    {
        // Building Frame Objects
        myFrame = new JFrame("Mathematician GUI"); // Parameter: whatever you put in the "Quotes" will be displayed as the title of the JFrame
        bluePanel = new JPanel();
        redPanel = new JPanel();
        yellowPanel = new JPanel();
        
        // Use Absolute Positioning on Panel
        myFrame.setLayout(null); // NOTE: when using a null layout, the programmer must setBounds or setSize for the content to be visible
        bluePanel.setLayout(null);
        redPanel.setLayout(null);
        yellowPanel.setLayout(null);
        
        
        // Position and Size the Frame & Panel
        myFrame.setBounds(0, 0, 1500, 3000); 
        bluePanel.setBounds(50, 100, 300, 200); 
        redPanel.setBounds(100, 20, 100, 200);
        yellowPanel.setBounds(300, 300, 1000, 1000);
        
        /*Parameter Explanaiton: 
         * Start the panel at a specified X & Y location (from top corner) 
         * FirstNum = X Co-ordinate, 
         * SecondNum = Y-Cordinate,
         * Then create a panel of specific Width and Length
         * ThirdNum = Width of Panel
         * FourthNum = Height of Panel
         */
        
        
        
        
        //myFrame.getContentPane().setBackground(Color.BLACK); //Setting the color so you can see how the panel is set in the frame
        bluePanel.setBackground(Color.BLUE);
        redPanel.setBackground(Color.RED);
        yellowPanel.setBackground(Color.YELLOW);
        
        
        // Put myPanel into the Frame
        myFrame.add(bluePanel);
        myFrame.add(redPanel);
        myFrame.add(yellowPanel);
        
        //Must make the Frame Visible
        myFrame.setVisible(true);
        
        
        // This will end the program when the JFrame is closed, otherwise it will run in the background FOREVER!!!!!!
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        
    }// End of Constructor JFrameExemplar1

    
        
    /*
     * Main -- Entry Point to any Program (Only 1 Main allowed per program == amongst all files!!!!!)
     * 
     * @parms   args of type String[] -- Arbitrary signature for the main
     * @return  None.
     */
    /*public static void main (String[] args) 
    {
        // Creating an instance of an Object called runGui which will run the program thus creating the basic (empty) JFrame 
        JFrameExemplar1 runGui = new JFrameExemplar1();
    }// End of Main
    */
} // End of JFrameExemplar1




/*
 * 
 * NOTES:
 * 
 * J-Frames require to be BUILT == Constructed
 * 
 * DO Not Think of it as Coding / Solving problems, but a step by step algorithm used for something like building a house. 
 * For example: You cant skip steps when building a house. You cant put a roof on a house without walls first. It wont work
 * 
 * 
 * 
 * Here are the steps to build a frame from scratch:
 * (1): Define the Elements (# frames & Panels) Needed
 *      --> Sketch out your Frame first, Then "Decalre" these Elements (as Global Var)
 *      
 * (2): Create them, Initialize these elements ("Object" Parts) == Build them in the Constructor
 * 
 * (3): Initially Everything Created is Invisible. You Cannot See Them!!!!! These Elements are Tiny and set Behind the UI/UX
 *      Need to .setLayout(); .setSize(), setBounds()
 * 
 * (4): Now you can start to change the Attributes like Color
 *      .setBackgroundColor(), BUT Remember Frames are empty and a canvas need to be added before you can change the color .getContentPane()
 * 
 * (5): Now you can add buttons, Sliders, TextBoxes, et al.... Features & Functionalities
 * 
 * (6): Finally Build or put together the Final Frame!!!! use .add()
 * 
 * (7): When Completed you will need to:
 *      .setVisible()
 *      ExitOnCLose
 * 
 * 
 * 
 * 
 * 
 * TestCode:
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */


