//import decalrations
import java.util.Scanner;
import javax.swing.JFrame; 
import javax.swing.JPanel; // import javax.swing.*; can use but this imports 1 000 000 other things yo do not need
import java.awt.Color;
import com.phidget22.*;

/**
 * Program Title: Mathemagician
 * Program Summary: Designed to assist a magician in performing magic regarding the manipulation of integers through arithmetic operations
 * Program Elements: 
 *  - System.out.println
 *  - Var declaration
 *  - Scanner
 *  - JFrame file/constructor to create the runGui object
 *  - do while loop
 *  - phidget file/constructor to create the runPhidget object, used for the LED blinker
 *  - getUserInput() method
 *  - repeatProgram() method 
 *  - wait() method
 *  - Thread.sleep() method
 * @author Michael Fung, Justin Strand
 * @version 5.4.1 (BlueJ)
 */





public class Mathemagician {
    // instance variables - replace the example below with your own
    // None Used

    /**
     * Constructor for objects of class Mathemagician
     */
    public Mathemagician()
    {
        // initialise instance variables
        //None Used
    } // END of constructor Mathmagician
    
    
    
    /*
    Purpose: Using the scanner class to get the user's input.
    param: none
    return: userInput
    */
    public static int getUserInput(){
        Scanner getInput = new Scanner(System.in);
        int userInput;
        
        System.out.print("Enter a number: ");
        while (!getInput.hasNextInt()){
        System.out.println("Invalid input. Please enter an integer.");
        getInput.next(); // Consume the invalid input
        System.out.print("Enter a number: ");
        }
    
        // If input is an integer, read it
        userInput = getInput.nextInt();
        return userInput;
    }
    
    
    
    
    
    /*
    Purpose: To determine whether or not a user wants to repeat the program
    param: none
    return: confirmRepeat
     */
    public static boolean repeatProgram(){
        Scanner getUserRepeatInput = new Scanner(System.in);
        String userRepeatInput;
        boolean confirmRepeat;
        
        System.out.println("Feel free to use any other value to test out the program, it should get 3 as the answer every single time. You can repeat the program by typing y");
        System.out.println();
        System.out.print("Repeat Program? YES (y) or NO (n): ");
        userRepeatInput = getUserRepeatInput.nextLine();
        
        
        //Analyzing user input
        if (userRepeatInput.equalsIgnoreCase("Y") || userRepeatInput.equalsIgnoreCase("YES") || userRepeatInput.equalsIgnoreCase("YS")){
            confirmRepeat = true;
        } else {
            confirmRepeat = false;
        }
        
        return confirmRepeat;    
    }//End of repeatProgram method
    
    
    
    
    
    /*
     *Purpose: to add delays between lines of code waitng to be executed
     *param: int for the delay in ms.
     *return: None.
     */
    public static void wait(int ms){
        try {
            Thread.sleep(ms);
        } 
        
        catch (InterruptedException ex){
            Thread.currentThread().interrupt();
        }
    }





    /*
    Purpose: Main of Class Mathemagician
    param: None.
    return: None.
     */
    public static void main(String[] args) throws Exception {
        
        //Variable declarations 
        int myNumber, stepOne, stepTwo, stepThree, stepFour, stepFive, stepSix;
        boolean repeatProgram;
        
        JFrameExemplar1 runGui = new JFrameExemplar1(); // runs GUI (JFrame)
        
        
        
        do {
        //Creates blank lines to "clear" the terminal
        for (int i = 0; i < 20; i++) {
            System.out.println();
        }
        
    
        
        //Title 
        System.out.println("##   ##    ##     #### ##  ###  ##           ##   ##    ##      ## ##     ####    ## ##   \n" +
        "  ## ##      ##    # ## ##   ##  ##            ## ##      ##    ##   ##     ##    ##   ##  \n" +
        " # ### #   ## ##     ##      ##  ##           # ### #   ## ##   ##          ##    ##       \n" +
        " ## # ##   ##  ##    ##      ## ###           ## # ##   ##  ##  ##  ###     ##    ##       \n" +
        " ##   ##   ## ###    ##      ##  ##           ##   ##   ## ###  ##   ##     ##    ##       \n" +
        " ##   ##   ##  ##    ##      ##  ##           ##   ##   ##  ##  ##   ##     ##    ##   ##  \n" +
        " ##   ##  ###  ##   ####    ###  ##           ##   ##  ###  ##   ## ##     ####    ## ## ");
        System.out.println();
        
        //Welcome
        System.out.println("Welcome to Mathemagician! A program designed to demonstrate how numbers can be manipulated as if it was a magic trick!");
        System.out.println();
        
        //Intro
        System.out.println("This program is designed to do the same arithmetic operations on any number and get 3 as the result no matter the initial value.");
        System.out.println();
        
        //Explanation
        System.out.println("To begin, enter any value in the input box below.");
        System.out.println();
        wait(1000);
        
        //Input
            myNumber = getUserInput();
            
            
            
        //Calculations    
            stepOne = myNumber * myNumber;
            stepTwo = stepOne + myNumber;
            stepThree = stepTwo / myNumber;
            stepFour = stepThree + 17;
            stepFive = stepFour - myNumber;
            stepSix = stepFive / 6;
            
        
            
        //Output
            System.out.println();
            System.out.println("First, multiply " + myNumber + " by itself and ... we get " + stepOne + ".");
            System.out.println();
            wait(1000);
            System.out.println("Then, we add " + myNumber + " (The value you entered) by " + stepOne + ". Which leaves us with " + stepTwo + ".");   
            System.out.println();
            wait(1000);
            System.out.println("Now we divide " + stepTwo + " with " + myNumber + ". Getting us " + stepThree + ".");
            System.out.println();
            wait(1000);
            System.out.println("Now add " + stepThree + " by 17. Which gets us " + stepFour + ".");
            System.out.println();
            wait(1000);
            System.out.println("After that we subtract " + stepFour + " with " + myNumber + ". Which should get us " + stepFive + ".");
            System.out.println();
            wait(1000);
            System.out.println("Finally, we divide " + stepFive + " by 6.");
            System.out.println();
            wait(1000);    
            System.out.println("The answer should be " + stepSix + ".");
            System.out.println();
            wait(1000);
            
        //Asking if user wants to repeat the program 
            repeatProgram = repeatProgram();//exit/loop condition
            
        } while (repeatProgram);//end of exit condition 
    
        
        
        //Thank you
            System.out.println("Thank you for using our program. Hope to see you soon.");
            wait(1000);
           
        //Runs Phidget
            BlinkLEDObj runPhidget = new BlinkLEDObj(); // Phidget
    }
    
}

//End of Program Comments

//Notes: BlinkLEDObj runPhidget = new BlinkLEDObj(); will not work if the phidget22.jar, com folder,or the .dll files are not installed/added

/* Test Codes
            int myNumber = (insert value of your choice);
            int stepOne = myNumber * myNumber;
            int stepTwo = stepOne + myNumber;
            int stepThree = stepTwo / myNumber;
            int stepFour = stepThree + 17;
            int stepFive = stepFour - myNumber;
            int stepSix = stepFive / 6;
            
*/