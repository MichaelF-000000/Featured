
//Add Phidgets Library | You added a file called phidget22 when configuring your project. Import gives you access to the Phidgets library code inside that file. 
import com.phidget22.*;



/**
 * Ttile: BlinkLED
 * Program Summary: 
 * PRogram Element List:
 * 
 * 
 *
 * @author (Teammates || Roles)
 * @version (a version number) 
 * @date (Last Updated)
 * 
 */
public class BlinkLEDObj {
    // Instance Variables
    
    //Create | Here you've created a DigitalOutput object for your LED. An object represents how you interact with your device. DigitalOutput is a class from the Phidgets library that's used to provide a voltage to things like LEDs.
    DigitalOutput redLED = new DigitalOutput(); 
    


    /**
     * Constructor for objects of class BlinkLED
     */
    public BlinkLEDObj() throws Exception {
        // Initialise Instance Variables
        // NONE. 
        
        
        
        //Address | This tells your program where to find the device you want to work with. Your LED is connected to port 1 and your code reflects that. IsHubPortDevice must be set if you are not using a Smart Phidget (more on this later).
        redLED.setHubPort(1);
        redLED.setIsHubPortDevice(true);

        //Open | Open establishes a connection between your object and your physical Phidget. You provide a timeout value of 1000 to give the program 1000 milliseconds (1 second) to locate your Phidget. If your Phidget can't be found, an exception will be thrown.
        redLED.open(1000);

        //Use your Phidgets | Here is where you can have some fun and use your Phidgets! You can turn your LED on/off by setting the state to true/false. The sleep command keeps your LED on by letting 1000 milliseconds pass before turning the LED off.
        while(true){
            redLED.setState(true);
            Thread.sleep(1000);
            redLED.setState(false);
            Thread.sleep(1000);
        } //END of While true
        
    }// END of Class BlinkLED

    
    
    
    
    
    /**
     * Main - Represents the Entry Point to the Program
     *
     * @param       String[] args   Deafult parameters for the JVM to recognize that method as its entry point. If we change the signature of the method, the program compiles but does not execute. 
     * @return      None. 
     * 
     * Handle Exceptions | Exceptions will happen in your code from time to time. These are caused by unexpected things happening. Make sure you’ve added "throws Exception" to your main method.
     * 
     */
   /* public static void main(String[] args) throws Exception {
        // Variable Declarations
        
        //BlinkLEDObj myRedLightBlinky = new BlinkLEDObj(); 
        

    }
*/
} //END of Class BlinkLED
  
        


/*
 * 
 * NOTES:
 * 
 * 
 * 
 * TEST CODE: 
 * 
 * 
 * 
 *
 */


