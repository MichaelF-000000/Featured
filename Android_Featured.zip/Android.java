//Import Declarations
import java.util.Scanner;
import java.lang.Math;
import java.util.HashSet;
import java.util.Arrays;
/**
 * Program Title: Android
 * 
 * Program Summary: A program designed for users to simulate the control of an android/drone in a terminal based environment with a variety of commands available. 
 *                  Designed for a user-friendly interface/experience (UI/UX) through 7 individual UI/UX functions (static methods). The program is based on the OOP approach: 
 *                  the program creates an instance of class Android to create the drone in the terminal when it is run, with the commands for the drone being non-static methods.
 *                  Additional elements of the program includes a JFrame, consisting of a drone in an image background, and a rover phidget element controlled with a thumbstick controller.
 *                  
 * Program Elements: (1) if-else statement (2) switch statement (3) HashSet (4) while loop (5) do-while loop (6) Scanner class and methods (7) Clear terminal (System.out.print('\u000C')) (8) JFrameExamplar1 class and object (runGui) (9) RoverThumbStick class and object (roverControl) (10) Thread.sleep()
 *  
 * @authors Michael Fung, Justin Strand
 * @version BlueJ Version 5.4.1
 * Last Updated: 1/30/2025
 */
public class Android
{
    //Instance Fields
    double totalDistanceTravelled;
    double horizontalPosition;
    double verticalPosition;
    double batteryPercentage;
    boolean droidStatus;
    
    //Static Variables Declarations
    static boolean repeatProgram = true;
    static Scanner getUserInput = new Scanner(System.in);
    
    
    
    
    //Constructor
    /**
     * Constructor for objects of class Android
     * Purpose: Creates instances of class Android and initializes the instances fields of objects created from this class. In this program, this particularly initializes the instance fields of the object "android". 
     * @param: None.
     */
    public Android(){
        totalDistanceTravelled = 0;
        horizontalPosition = 0;
        verticalPosition = 0;
        batteryPercentage = 50;
        droidStatus = false;
    }//End of Android constructor
    
    
    
    
    
    //Methods
    /**
     * Purpose: Prints off a command list to be provided to the user, assisting them in the process of inputing valid commands to control the drone
     * @param: None.
     * @return: None.
     */
    public void commandList(){
        System.out.println("You are now in the launch site.");
        System.out.println("Take a moment to look at the list below, it provides you with a series of actions that you can order your drone to do.");
        System.out.println("Just a reminder: every time you use one of the flying commands, the drone will start to lose its battery level. But do not worry! You can always recharge the drone back to its full with the \"CHARGE BATTERY\" command.");
        
        blankLines(1);
        System.out.println("-----COMMAND LIST-----");
        System.out.println("A = Activate drone");
        System.out.println("D = Deactivate drone");
        System.out.println("H = Fly horizontally");
        System.out.println("V = Fly vertically");
        System.out.println("C = Charge battery");
        System.out.println("P = Display current drone position");
        System.out.println("R = Return drone to launch site");
        System.out.println("T = Display total distance travelled");
        System.out.println("STOP = Stop program");
        blankLines(1);
    }//End of commandList() method
    
    
    
    
    
    /**
     * Purpose: Method that will be executed when the user inputs "A", assigns droidStatus to true if it wasn't prior to the method call. This allows 5 additional drone commands to be used.
     * @param: None
     * @return: None
     */
    public void activate(){
        if (droidStatus){
            System.out.println("The drone is already activated!");
        } else{
            droidStatus = true; 
            System.out.println("The drone is now activated!");
        }
    }//End of activate() method
    
    
    
    
    
    /**
     * Purpose: Method that will be executed when the user inputs "D", assigns droidStatus to false if it wasn't prior to the method call. This prevents 5 drone commands from being called.
     * @param: None
     * @return: None
     */
    public void deactivate(){  
        if (!droidStatus){
            System.out.println("The drone is already deactivated!");
        } else {
            droidStatus = false;
            System.out.println("The drone is now deactivated!");
        }
    }//End of deactivate() method
    
    
    
    
    
    /**
     * Purpose: Method that will be executed when the user inputs "V", adjusts the drone's vertical position in the 2d plane by subtracting/adding the value of verticalPosition by the user's input (of type: double)
     * @param: None
     * @return: None
     */
     public void moveDroneVertically(){
        String directionInput; 
        double displacementValue;
        double userInput = 0;
        boolean proceedMovement;
        
        System.out.println("FLYING DIRECTION?");
        System.out.print("UP (U), DOWN (D): ");
        
        directionInput = getUserStringInput();
        directionInput = directionInput.toUpperCase();//makes the user's input not case sensitive
        
        blankLines(1);
        
        if (!directionInput.equals("U") && !directionInput.equals("D")){
            while (!directionInput.equals("U") && !directionInput.equals("D")){
                System.out.print("You entered an incorrect value! Please enter \"U\" or \"D\": ");
                directionInput = getUserStringInput();
                directionInput = directionInput.toUpperCase();
                blankLines(1);
            }
        }
    
        switch (directionInput){
          case "U":
            if (verticalPosition == 10){
                System.out.println("You are already at the height limit!");
            } else {
                System.out.println("How many meters do you want your drone to travel upwards?");
                if (verticalPosition > 0){
                    System.out.println("CAUTION: There is a height limit of 10 meters and you are currently hovering at " + verticalPosition + " meters off the ground.");
                } else {
                    System.out.println("CAUTION: There is a height limit of 10 meters.");
                }
                System.out.print("You entered (please enter without units or negative signs): ");
                
                displacementValue = getUserDoubleInput();
                displacementValue = Math.abs(displacementValue);
                blankLines(1);
                
                if (displacementValue == 0){
                    System.out.println("The drone did not move as you entered 0"); 
                } else if ((verticalPosition + displacementValue) <= 10){
                    verticalPosition += displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters upwards and is now hovering at " + verticalPosition + " meters off the ground.");
                } else {
                    System.out.println("The drone cannot travel that high!");
                }
            
            }
            break;
          case "D":
            if (verticalPosition == 0){
                System.out.println("You can't travel downwards! You drone is currently on the ground!");
            } else {
                System.out.println("How many meters do you want your drone to travel downwards?");
                System.out.println("CAUTION: You can't enter a value larger than the drone's current hovering distance, or else the drone will crash. You are currently hovering at " + verticalPosition + " meters off the ground.");
                System.out.print("You entered (please enter without units or negative signs): ");
                
                
                displacementValue = getUserDoubleInput();
                displacementValue = Math.abs(displacementValue);
                
                blankLines(1);
                if ((verticalPosition - displacementValue) > 0){
                    verticalPosition -= displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters downwards and is now hovering at " + verticalPosition + " meters off the ground.");
                } else if ((verticalPosition - displacementValue) == 0){
                    verticalPosition -= displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters downwards and has landed on the ground.");
                } else {
                    System.out.println("The drone cannot travel this low as it will crash in the ground!");
                }
            }
            break;
          default:
            System.out.println("Error. Please contact 260142s@sd44.ca to report the issue. Much appreciated.");
            break;
        }
    }//End of moveDroneVertically() method
    
    
    
    
    
    /**
     * Purpose: Method that will be executed when the user inputs "H", adjusts the drone's horizontal position in the 2d plane by subtracting/adding the value of horizontalPosition by the user's input (of type: double)
     * @param: None
     * @return: None
     */
    public void moveDroneHorizontally(){
        String directionInput; 
        double displacementValue;
        double userInput = 0;
        boolean proceedMovement;
        
        if (verticalPosition > 0){
            
            System.out.println("FLYING DIRECTION?");
            System.out.print("LEFT (L), RIGHT (R): ");
            

            directionInput = getUserStringInput();
            directionInput = directionInput.toUpperCase();
            
            blankLines(1);
            
            while (!directionInput.equals("L") && !directionInput.equals("R")){
                System.out.print("You entered an incorrect value! Please enter \"L\" or \"R\":");
                directionInput = getUserStringInput();
                directionInput = directionInput.toUpperCase();
            }//end of while loop
        
        
            switch (directionInput){
              case "L":
                System.out.println("How many meters do you want your drone to travel to the left?");            
                if (horizontalPosition == 0){
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away from the launch site.");
                } else if (horizontalPosition < 0){
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away to the left of the launch site.");
                } else {
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away to the right of the launch site.");
                }//end of if-else-if statement
                System.out.print("You entered (please enter without units or negative signs): ");
                
                displacementValue = getUserDoubleInput();
                displacementValue = Math.abs(displacementValue);
    
                blankLines(1);
                if (displacementValue == 0){
                    System.out.println("The drone did not move as you entered 0.");
                } else if (((horizontalPosition - displacementValue) >= -100) && ((horizontalPosition - displacementValue) < 0)){
                    horizontalPosition -= displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters to the left and is now " + Math.abs(horizontalPosition) + " meters away to the left of the launch site.");
                } else if (((horizontalPosition - displacementValue) <= 100) && ((horizontalPosition - displacementValue) > 0)){
                    horizontalPosition -= displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters to the left and is now " + Math.abs(horizontalPosition) + " meters away to the right of the launch site.");
                } else if (horizontalPosition - displacementValue == 0){
                    System.out.println("The drone has travelled " + displacementValue + " meters to the left and is now directly on top of the launch site.");
                } else {
                    System.out.println("The drone cannot travel this far away from the signal!");
                }//end of if-else-if statement
                break;
              case "R":
                System.out.println("How many meters do you want your drone to travel to the right?");            
                if (horizontalPosition == 0){
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away from the launch site.");
                } else if (horizontalPosition < 0){
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away to the left of the launch site.");
                } else {
                    System.out.println("CAUTION: There is a maximum signal range of 100 meters from the launch site and you are currently " + Math.abs(horizontalPosition) + " meters away to the right of the launch site.");
                }//end of if-else-if statement
                System.out.print("You entered (please enter without units or negative signs): ");
                
                displacementValue = getUserDoubleInput();
                displacementValue = Math.abs(displacementValue);
    
                blankLines(1);
                if (displacementValue == 0){
                    System.out.println("The drone did not move as you entered 0.");
                } else if (((horizontalPosition + displacementValue) >= -100) && ((horizontalPosition - displacementValue) < 0)){
                    horizontalPosition += displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters to the right and is now " + Math.abs(horizontalPosition) + " meters away to the left of the launch site.");
                } else if (((horizontalPosition + displacementValue) <= 100) && ((horizontalPosition + displacementValue) > 0)){
                    horizontalPosition += displacementValue;
                    totalDistanceTravelled += displacementValue;
                    batteryPercentage -= displacementValue/10;
                    System.out.println("The drone has travelled " + displacementValue + " meters to the right and is now " + Math.abs(horizontalPosition) + " meters away to the right of the launch site.");
                } else if (horizontalPosition + displacementValue == 0){
                    System.out.println("The drone has travelled " + displacementValue + " meters to the right and is now directly on top of the launch site.");
                } else {
                    System.out.println("The drone cannot travel this far away from the signal!");
                }//end of if-else-if statement
                break;
              default:
                System.out.println("Error.");
                break;
            }//end of switch statement
        
        } else {
            System.out.println("The drone cannot travel horizontally when it's on the ground!.");
        }//end of if-else statement
        
    }//End of moveDroneHorizontally() method
    
    
    
    
    
    /**
     * Purpose: Retrieves a type double input from the user and adds it to batteryPercentage. Conditional statements and/or methods of class Math prevents the value of batteryPercentage to exceed the range [0,100] 
     * @param: None
     * @return: None
     */
    public void chargeBattery(){
        String userStringInput;
        double userDoubleInput;
        double timeToFull;
        double preventOverCharge;
        
        if (batteryPercentage == 100){
            System.out.println("The drone's battery is full! No charging needed!");
        } else {
            blankLines(1);
            System.out.println("Do you wish to charge the drone? Yes (Y), No (N)");
            System.out.print("You entered: ");
            userStringInput = getUserStringInput();
            userStringInput = userStringInput.toUpperCase();
            
            while (!(userStringInput.equals("Y")) && !(userStringInput.equals("N"))){
                System.out.println("Please enter a valid input! (\"Y\" or \"N\")");
                userStringInput = "";
                userStringInput = getUserStringInput();
                userStringInput = userStringInput.toUpperCase();
            }//end of while loop
            
            if (userStringInput.equals("Y")){//if userStringInput.equals("N"), nothing is executed further in this method and this method ends, allowing the user to enter another command 
                blankLines(1);
                System.out.println("Every minute of charging = drone gains 1% battery.");
                System.out.println("How long do you wish to charge your drone? (In minutes)");
                System.out.print("You entered (please enter the number only, without units or negative signs):");
                userDoubleInput = getUserDoubleInput();
                userDoubleInput = Math.abs(userDoubleInput);
                blankLines(1);
                preventOverCharge = batteryPercentage + userDoubleInput - 100;
                timeToFull = 100 - batteryPercentage;
                if (preventOverCharge > 0){
                    System.out.println("You only need " + timeToFull + " minutes to charge the drone back to 100%!");
                    System.out.println("Processing...");
                    delay(2000);
                    blankLines(1);
                    System.out.println("The drone charged for " + timeToFull + " minutes and saved you " + preventOverCharge + " minutes from not overcharging the battery!");
                    batteryPercentage = 100;
                    System.out.println("The drone's battery is now at " + batteryPercentage + "%.");
                } else {
                    System.out.println("Processing...");
                    delay(2000);
                    batteryPercentage += userDoubleInput;
                    blankLines(1);
                    System.out.println("The drone charged for " + userDoubleInput + " minutes and its battery level is now at " + batteryPercentage + "%.");
                }
            }//end of if statement
        }//end of if-else statement
    }//End of chargeBattery() method
    
    
    
    
    
    /**
     * Purpose: Displays/prints the vertical and horizontal coordinates to the user
     * @param: None
     * @return: None
     */
    public void displayCurrentPosition(){
        String sideOfMap;
        boolean airborne = false;
        
        if (horizontalPosition == 0){
            sideOfMap = "origin";
        } else {
            sideOfMap = horizontalPosition < 0 ? "left" : "right";
        }//end of if statement
        
        airborne = verticalPosition > 0;
        
        switch (sideOfMap){
          case "origin":
            if (!airborne){
                System.out.println("The drone is currently stationary at the launch site."); 
            } else {
                System.out.println("The drone is currently hovering at " + verticalPosition + " meters off the ground directly on top of the launch site.");
            }//end of if statement
            break;
          case "left":
            System.out.println("The drone is currently hovering at " + verticalPosition + " meters off the ground, " + Math.abs(horizontalPosition) + " meters away to the left of the launch site.");
            break;
          case "right":
            System.out.println("The drone is currently hovering at " + verticalPosition + " meters off the ground, " + Math.abs(horizontalPosition) + " meters away to the right of the launch site.");
            break;
          default:
            System.out.println("Error.");
            break;
            
        }//end of switch statement
    }//End of displayCurrentPosition() method
    
    
    
    
    
    /**
     * Purpose: Resets the value of horizontalPosition and verticalPosition
     * @param: None
     * @return: None
     */
    public void returnToLaunchSite(){
        String userInput;
        System.out.println("Returning the drone back to the launch site would drain 40% of its battery as it takes more energy for the drone to self navigate.");
        System.out.print("Do you wish to proceed? Yes (Y), No (N): ");
        userInput = getUserStringInput();
        userInput = userInput.toUpperCase();
        
        while (!userInput.equals("Y") && !userInput.equals("N")){
            System.out.print("Please enter \"Y\" or \"N\": ");
            userInput = getUserStringInput();
            userInput = userInput.toUpperCase();
        }//end of while loop
        
        if (userInput.equals("Y")){
            horizontalPosition = 0;
            verticalPosition = 0;
            batteryPercentage -= 40;
            
            System.out.println("The drone has returned to the launch site.");
        }//end of if statement
    }//End of returnToLaunchSite() method
    
    
    
    
    
    /**
     * Purpose: Displays/prints the total distance covered by the drone back to the user
     * @param: None
     * @return: None
     */
    public void displayTotalDistanceTravelled(){
        System.out.println("The drone has travelled a total of " + totalDistanceTravelled + " meters in the air.");
    }

    
    
    
    
    /**
     * Purpose: Consists of a tutorial to familiarize the user with the program and acquires continuous input from the user afterwards to call on drone-related methods until the user decides to stop the program through typing "STOP"
     * @param: None
     * @return: None
     */
    public void requestAction(){
        //Variable Declarations
        String userTutorialInputOne;
        String userTutorialInputTwo;
        String userCommandInput;
        String userProceedInput;//multiple string variables are declared to minimize input errors, each variable is for one section only
        int numOfLoops = 0;
        HashSet<String> validInputs = new HashSet<String>(Arrays.asList("A", "D", "H", "V", "C", "P", "R", "T", "STOP"));
        
        
        commandList();
        
        //Start of Tutorial
        
        System.out.println("Drone Battery Percentage: " + batteryPercentage + "%");
        blankLines(1);
        System.out.println("Let's start with a simple command. To actually fly the drone, you have to activate it first. Enter \"A\" to do so.");
        System.out.print("You entered: ");
        
        userTutorialInputOne = getUserStringInput();
        userTutorialInputOne = userTutorialInputOne.toUpperCase();
        
        while (!userTutorialInputOne.equals("A")){
            System.out.print("You entered an incorrect value! Please enter the character \"A\": ");
            userTutorialInputOne = getUserStringInput();
            userTutorialInputOne = userTutorialInputOne.toUpperCase();
        }//end of while loop
        //userTutorialInputOne must equal to "A" to proceed pass this point
        //conditional statement not needed to verify the user's input
        System.out.println("Processing...");
        delay(2000);
        blankLines(1);
        activate();
 
        delay(2000);
        System.out.print('\u000C');
        
        commandList();
        System.out.println("Drone Battery Percentage: " + batteryPercentage + "%");
        blankLines(1);
        System.out.println("Let's fly the drone!");
        System.out.println("Make the drone hover on the ground with the \"fly vertically\" command by entering the letter that corresponds to it.");
        System.out.print("You entered: ");
        
        userTutorialInputTwo = getUserStringInput();
        userTutorialInputTwo = userTutorialInputTwo.toUpperCase();
        while (!userTutorialInputTwo.equals("V")){
            System.out.print("You entered an incorrect value! Please enter the character \"V\": ");
            userTutorialInputTwo = getUserStringInput();
            userTutorialInputTwo = userTutorialInputTwo.toUpperCase();
        }//end of while loop
        //userTutorialInputTwo must equal to "V" to proceed pass this point
        //conditional statement not needed to verify the user's input
        System.out.println("Processing...");
        delay(2000);
        blankLines(1);
        moveDroneVertically();
        
        //Precaution if the user chose the "DOWNWARDS" option
        while (verticalPosition == 0){
            
            blankLines(1);
            System.out.println("Please use the \"fly vertically\" command again! The drone is still on the ground!");
            System.out.print("You entered: ");
            userTutorialInputTwo = getUserStringInput();
            userTutorialInputTwo = userTutorialInputTwo.toUpperCase();
            
            while (!userTutorialInputTwo.equals("V")){
                System.out.print("You entered an incorrect value! Please enter the character \"V\": ");
                userTutorialInputTwo = getUserStringInput();
                userTutorialInputTwo = userTutorialInputTwo.toUpperCase();
            }//End of while loop
            moveDroneVertically();
        }//End of while loop
        
        
        
        delay(2000);
        blankLines(1);
        System.out.println("This is the end of the tutorial! Please continue to try out any of the commands on the list above!");
        delay(1000);
        System.out.println("Exiting tutorial in 3.");
        delay(1500);
        System.out.println("Exiting tutorial in 2.");
        delay(1500);
        System.out.println("Exiting tutorial in 1.");
        delay(1500);
        System.out.print('\u000C');
        commandList();
        System.out.println("Drone Battery Percentage: " + batteryPercentage + "%");
        blankLines(1);
        System.out.println("This is the end of the tutorial! Please continue to try out any of the commands on the list above!");
        //End of tutorial
        
        while (repeatProgram){
            if (numOfLoops != 0){
                commandList();
                System.out.println("Drone Battery Percentage: " + batteryPercentage + "%");
                blankLines(1);
            }//End of if statement
            //userInput ="";
            System.out.print("Enter any command from the list: ");
            userCommandInput = getUserStringInput();
            userCommandInput = userCommandInput.toUpperCase();
            blankLines(1);
            
            while (!validInputs.contains(userCommandInput)){
                System.out.println("Please enter a valid command!");
                System.out.print("You entered: ");
                userCommandInput = getUserStringInput();
                userCommandInput = userCommandInput.toUpperCase();
            }//End of while loop
            //the JVM will only break out of this loop when validInputs.contains(userCommandInput) == true.
            //Additional conditonal statement to verify the validity of the user's input is not necessary and will only slow down the program.
        
            switch (userCommandInput){
              case "A":
                activate();
                break;
              case "D":
                deactivate();
                break;
              case "H"://these commands (H-T) require the drone to be activated to be used.
              case "V":
              case "P":
              case "R":
              case "T":
                if (!droidStatus){
                    System.out.println("You must activate the drone first before using this command!");
                } else {
                    switch (userCommandInput){
                      case "H":
                        if (batteryPercentage >= 30){
                            moveDroneHorizontally();
                        } else {
                            System.out.println("The drone's battery percentage is critically low. The horizontal flying command is not accessible until the drone is recharged to a battery level of at least 30%.");
                            chargeBattery();
                        }
                        break;
                      case "V":
                        if (batteryPercentage >= 30){
                            moveDroneVertically();
                        } else {
                            System.out.println("The drone's battery percentage is critically low. The vertical flying command is not accessible until the drone is recharged to a battery level of at least 5%.");
                            chargeBattery();
                        }       
                        break;
                      case "P":
                        displayCurrentPosition();
                        break;
                      case "R":
                        if (batteryPercentage >= 50){
                            returnToLaunchSite();
                        } else {
                            System.out.println("A drone battery percentage of 50% is required to use this command safely, consider using the \"Charge Battery\" command.");
                        }
                        break;
                      case "T":
                        displayTotalDistanceTravelled();
                        break;
                      default:
                        System.out.println("Error.");
                        break;
                    }//End of switch statement
                }//End of if-else statement
                break;
              case "C":
                chargeBattery();
                break;
              case "STOP":
                endProgram();
                break;
              default:
                System.out.println("Error.");
                break;
            }//End of switch statement
            
       
            
            blankLines(1);
            
            if (repeatProgram){//condition would not be met ONLY WHEN endProgram() is called or "C" is inputted
                System.out.print("Press \"ENTER\" WITHOUT anything in the input box to proceed with another command: ");
                userProceedInput = "";
                userProceedInput = getUserStringInput();
                while (!userProceedInput.equals("")){
                    System.out.print("Press \"ENTER\" without anything in the input box to proceed:");
                    userProceedInput = getUserStringInput();
                }//end of while loop
            }//end of if statement
            System.out.println("Processing...");
            numOfLoops++;
            delay(1200);
            System.out.print('\u000C');
        }//end of while loop
    }//end of requestAction() method
    
    
    
    
    
    //Functions 
    /**
     * Purpose: Creates a desired amount of whitespace/blank lines on the terminal
     * @param: int numOfBlankLines, the value of numOfBlankLines deterines how many lines will be created for whitespace
     * @return: None
     */
    public static void blankLines(int numOfBlankLines){
        for (int i = 0; i < numOfBlankLines; i++){
            System.out.println();
        }//end of for loop
    }//end of blankLines() method
    
    
    
    
    
    /**
     * Purpose: Displays/prints the tile of the program, ASCII generated title
     * @param: None
     * @return: None
     */
    public static void title(){
        System.out.println("               AAA               NNNNNNNN        NNNNNNNNDDDDDDDDDDDDD      RRRRRRRRRRRRRRRRR        OOOOOOOOO     IIIIIIIIIIDDDDDDDDDDDDD        ");
        System.out.println("              A:::A              N:::::::N       N::::::ND::::::::::::DDD   R::::::::::::::::R     OO:::::::::OO   I::::::::ID::::::::::::DDD     ");
        System.out.println("             A:::::A             N::::::::N      N::::::ND:::::::::::::::DD R::::::RRRRRR:::::R  OO:::::::::::::OO I::::::::ID:::::::::::::::DD   ");
        System.out.println("            A:::::::A            N:::::::::N     N::::::NDDD:::::DDDDD:::::DRR:::::R     R:::::RO:::::::OOO:::::::OII::::::IIDDD:::::DDDDD:::::D  ");
        System.out.println("           A:::::::::A           N::::::::::N    N::::::N  D:::::D    D:::::D R::::R     R:::::RO::::::O   O::::::O  I::::I    D:::::D    D:::::D ");
        System.out.println("          A:::::A:::::A          N:::::::::::N   N::::::N  D:::::D     D:::::DR::::R     R:::::RO:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("         A:::::A A:::::A         N:::::::N::::N  N::::::N  D:::::D     D:::::DR::::RRRRRR:::::R O:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("        A:::::A   A:::::A        N::::::N N::::N N::::::N  D:::::D     D:::::DR:::::::::::::RR  O:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("       A:::::A     A:::::A       N::::::N  N::::N:::::::N  D:::::D     D:::::DR::::RRRRRR:::::R O:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("      A:::::AAAAAAAAA:::::A      N::::::N   N:::::::::::N  D:::::D     D:::::DR::::R     R:::::RO:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("     A:::::::::::::::::::::A     N::::::N    N::::::::::N  D:::::D     D:::::DR::::R     R:::::RO:::::O     O:::::O  I::::I    D:::::D     D:::::D");
        System.out.println("    A:::::AAAAAAAAAAAAA:::::A    N::::::N     N:::::::::N  D:::::D    D:::::D R::::R     R:::::RO::::::O   O::::::O  I::::I    D:::::D    D:::::D ");
        System.out.println("   A:::::A             A:::::A   N::::::N      N::::::::NDDD:::::DDDDD:::::DRR:::::R     R:::::RO:::::::OOO:::::::OII::::::IIDDD:::::DDDDD:::::D  ");
        System.out.println("  A:::::A               A:::::A  N::::::N       N:::::::ND:::::::::::::::DD R::::::R     R:::::R OO:::::::::::::OO I::::::::ID:::::::::::::::DD   ");
        System.out.println(" A:::::A                 A:::::A N::::::N        N::::::ND::::::::::::DDD   R::::::R     R:::::R   OO:::::::::OO   I::::::::ID::::::::::::DDD     ");
        System.out.println("AAAAAAA                   AAAAAAANNNNNNNN         NNNNNNNDDDDDDDDDDDDD      RRRRRRRR     RRRRRRR     OOOOOOOOO     IIIIIIIIIIDDDDDDDDDDDDD     ");
        blankLines(2);
    }//End of title() function
    
    
    
    
    
    /**
     * Purpose: Displays/prints welcome messages to the terminal
     * @param: None
     * @return: None
     */                                                                                                                                                 
    public static void welcome(){
        System.out.println("Hello!");
        System.out.println("Welcome to Android!");
        System.out.println("This is a program where you can control your own android/drone in a text-based environment.");
        blankLines(2);
    }//End of welcome() function
    
    
    
    
                                                                                                                                                  
    /**
     * Purpose: Displays/prints the introduction messages to the terminal
     * @param: None
     * @return: None
     */
    public static void intro(){
        System.out.println("With the press of a key on your keyboard, you too can simulate what it's like to fly a drone.");
        System.out.println("Our program is designed to be as realistic as possible, meaning that we've incorperated various factors that would normally affect real life drones into the program.");
        System.out.println("These include: physical limits to where the drone can travel in the air, a signal range/limit, and a battery that would slowly drain.");
        System.out.println("But do not worry! There is no \"game over\" in this program! Our program is specifically designed to prevent you from damaging the drone.");
        blankLines(2);
    }//End of intro() function
    
    
    
    
    
    /**
     * Purpose: Displays/prints the explanation message to the terminal. Acquires user input to redirect the user to the drone area.
     * @param: None
     * @return: None
     */   
    public static void explanation(){
        String userBeginInput;
        System.out.println("By typing the letter that corresponds to one of the many commands listed in the command list that will be shown to you,");
        System.out.println("you can signal your drone to do actions ranging from activating it to even flying in a 2D plane!");
        
        blankLines(10);

        System.out.println("#       ####### ####### ###  #####                 ######  #######  #####  ### #     # ");
        System.out.println("#       #          #    ### #     #                #     # #       #     #  #  ##    # ");
        System.out.println("#       #          #     #  #                      #     # #       #        #  # #   # ");
        System.out.println("#       #####      #    #    #####                 ######  #####   #  ####  #  #  #  # ");
        System.out.println("#       #          #              #                #     # #       #     #  #  #   # # ");
        System.out.println("#       #          #        #     #                #     # #       #     #  #  #    ## ");
        System.out.println("####### #######    #         #####                 ######  #######  #####  ### #     # ");
        blankLines(2);
        System.out.println("PRESS \"ENTER\" to begin the ANDROID experience.");
        
        System.out.print("You entered: ");
        userBeginInput = getUserStringInput();
        
        while (!userBeginInput.equals("")){
            System.out.print("Press ENTER without anything in the text box to begin your experience:");
            userBeginInput = getUserStringInput();
        }//End of while loop
            
        System.out.println("Processing...");
        delay(2000);
    }//End of explanation() function
    
    
    
    
    
    /**
     * Purpose: Asks if the user wants to stop the program. If it is confirmed, repeatProgram is set to false, stopping the while loop in requestAction() and consequently allowing thankYou() to be called.
     * @param: None
     * @return: None
     */
    public static void endProgram(){
        String userInput;
        
        System.out.print("Do you wish to stop the program? Yes (Y), No (N): ");
        userInput = getUserStringInput();
        userInput = userInput.toUpperCase();
        
        while (!userInput.equals("Y") && !userInput.equals("N")){
            System.out.print("Please enter \"Y\" or \"N\": ");
            userInput = getUserStringInput();
            userInput = userInput.toUpperCase();
        }//end of while loop
        
        if (userInput.equals("Y")){
            repeatProgram = false;
        }//end of if statement
    }//End of endProgram function
    
    
    
    
    
    /**
     * Purpose: Acquires a string input from the user, validates if the scanner input can be retrieved with hasNextLine(). If not, a loop will run indefinitely until a valid input is retrieved.
     * @param: None
     * @return: userStringInput, the user's valid string input
     */
    public static String getUserStringInput(){
        String userStringInput;
        boolean validStringInput = false;
        
        do {
            validStringInput = getUserInput.hasNextLine();
            if (!validStringInput){
                System.out.print("Please enter a valid input:");
                getUserInput.nextLine();
            }//end of if statement
        } while (!validStringInput);//end of do-while loop
             
        userStringInput = getUserInput.nextLine();
        
        return userStringInput;
    }//End of getUserStringInput() function

    
    
    
    
    /**
     * Purpose: Acquires a input of the double data type from the user, validates if the scanner input can be retrieved with hasNextDouble(). If it cannot be retrieved, then the input is consumed by nextLine() and the user is asked to enter an input again. 
     *          This cycle repeats until a valid double input is successfully retrieved.
     * @param: None
     * @return: userDoubleInput, the user's valid double input
     */
    public static double getUserDoubleInput(){
        double userDoubleInput = 0;
        boolean validDoubleInput = false;
        
        validDoubleInput = getUserInput.hasNextDouble();
        
        if (validDoubleInput){
            userDoubleInput = getUserInput.nextDouble();
            getUserInput.nextLine();
        } else {
            do {
                getUserInput.nextLine();//consumes invalid data types
                blankLines(1);
                System.out.print("Please enter a valid input (numbers):");
                validDoubleInput = getUserInput.hasNextDouble();
            } while (!validDoubleInput);//End of do-while loop
            //JVM will break free from loop when validDoubleInput == true.
            //Additional conditional Statement not required
            userDoubleInput = getUserInput.nextDouble();
            getUserInput.nextLine();
        }//End of if-else statement
        
        return userDoubleInput;
    }//End of getUserDoubleInput() function
    
        
        
        
        
    /**
     * Purpose: Prints the thank you messages to the terminal, an ASCII drone image is also printed. Basic instructions to the rover phidget are briefly explained
     * @param: None
     * @return: None
     */
    public static void thankYou(){
        System.out.println("Thank you for using our ANDROID program! We hope you had a good experience.");
        System.out.println("If you have some feedback about our program, feel free to email 260142s@sd44.ca to do so. Any feedback is appreciated.");
        System.out.println("Check out our physical rover phidget too! You can control it with a thumbstick control and experience what it's like to control an ANDROID in real life!");
        blankLines(5);
        
        System.out.println("                                                                                        %                                                                     ");
        delay(100);
        System.out.println("                                                                                  @@@@@@@            @@@@                                                     ");
        delay(100);
        System.out.println("                                                                            @@@@@@@                   @@@@@                                                   ");
        delay(100);
        System.out.println("                                                                      %@@@@@@                           @@@@@@                                                ");
        delay(100);
        System.out.println("                                                                  @@@@@                                   @@@@@@                                              ");
        delay(100);
        System.out.println("                                                          @@@@@@@@                                          @@@@@@                                            ");
        delay(100);
        System.out.println("                                                 @@@@@@@@@@@@@@@@@                                            @@@@@@                                          ");
        delay(100);
        System.out.println("                                            @@@@@@@@@@@@@@@@@@@@@@@                                             @@@@@@                                        ");
        delay(100);
        System.out.println("                                       @@@@@@@@@@@@@@@@    @@@@@@@@                                                @@@@                                       ");
        delay(100);
        System.out.println("                                  @@@@@@@@@@@@@@            @%%@@@                                                  @@@@@                                     ");
        delay(100);
        System.out.println("                                 @@@@@                        @%%@@@                                                 @@@@@@                                   ");
        delay(100);
        System.out.println("                                                               @@%%%@@%%%%%%%%%%@@@@@@@@@%@%                        @@@@@@@@@@                                ");
        delay(100);
        System.out.println("                    @@@@@                                        @@@@%%%%%%%%%%%%%%%@%@@@@@@@@@                     @@@@@@@@@@@@@                             ");
        delay(100);
        System.out.println("                    @@@@@@                                         @%%%%%%%%%%%%%%%@@@@@@@@@@@@@@@          %@@@@@@@@@@@@@@@@@@@@@@                           ");
        delay(100);
        System.out.println("                   @@@@@@@                                  @@@%%%%%%%%%%%%%%%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                        ");
        delay(100);
        System.out.println("                   @@@@@@@                             %%%%@@@@@@%%%%%%%%%%%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@        @@@@@@@@@@@                      ");
        delay(100);
        System.out.println("                   @@@@@@@@                         %%%%@@@@@@@@%%%%%%%%%%%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                    @@@@@@@@@@                    ");
        delay(100);
        System.out.println("                   @@@@@@@@                        @@@@@@@@@@@@%%%%%%%%@%%%%%@@@@@@@@@@@@@@@@@@@@@                               @@@@@@@@@@                  ");
        delay(100);
        System.out.println("                   @@@@@@@                        @@@@@@@@@@@@@@@@%%%@@%%%%@@@@@@@@@@@@@@@@@@@@@@                                    @@@@@@@                 ");
        delay(100);
        System.out.println("                   @@@@@                          @@@@@@@@@@@@@@@@@@@%%@@@@@@@@@@@@@@@@@@@@@@@@                                         @@@@@@               ");
        delay(100);
        System.out.println("                    @@@@@@                       %%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                             @@               ");
        delay(100);
        System.out.println("                  @@@@@@@@         %%%%%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                                               ");
        delay(100);
        System.out.println("                  %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                            @@@@@                   ");
        delay(100);
        System.out.println("                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                         @@@@@@@@@@                   ");
        delay(100);
        System.out.println("                @@@@@@@@@@@@@@@@@@@@@@           %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                  @@@@@@@@@@                       ");
        delay(100);
        System.out.println("                @@@@@@@                         %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                           @@@@@@@@@@@                          ");
        delay(100);
        System.out.println("                @@@@@@@                          @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                     @@@@@@@@@@@                               ");
        delay(100);
        System.out.println("                @@@@@@@                           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    @@@@@@@@@@@                @@@@@@@@@@                                 ");
        delay(100);
        System.out.println("                 @@@@@                               @@ @@@@@@@@@@@@@@@@@@@@@@@@@@        @@@@@@@@@@@           @@@@@@@@                                    ");
        delay(100);
        System.out.println("                 @@@@@                                     @@@@@@@@@@@@@@@@@@@@              @@@@@@@@@@@   @@@@@@@@@                                        ");
        delay(100);
        System.out.println("                  @@@@                                        @@@@@@@@  @@@@                    @@@@@@@@@@@@@@@@@@@                                         ");
        delay(100);
        System.out.println("                                                                                                  @@@@@@@@@@@@@@@@@                                         ");
        delay(100);
        System.out.println("                                                                                               @@@@@@@@@@@@@@@@@@@@                                         ");
        delay(100);
        System.out.println("                                                                                           @@@@@@@@@@@@@@@@@@@@@@@@@                                        ");
        delay(100);
        System.out.println("                                                                                        @@@@@@@@@@@@@@@@@@ @@@@@@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                     @@@@@@@@@@@@@@@@@        @@@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                  @@@@@@@@@@@@@@@              @@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                @@@@@@@@@@@                    @@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                  @@                           @@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                                               @@@@@@                                       ");
        delay(100);
        System.out.println("                                                                                                               @@@@@                                        ");
        delay(100);
        System.out.println("                                                                                                                @@                                          ");
    }//End of thankYou() function
    
    

    
    
    /**
     * Purpose: Uses Thread.sleep() to create a specfic delay between the execution of different lines of code. 
     * @param: int DelayTimeMs, the specified amount of time in ms for the delay
     * @return: None
     */
        public static void delay(int delayTimeMs){
        try {
            Thread.sleep(delayTimeMs);            
        } catch (InterruptedException e){
            System.out.println("Error.");
        }//End of try + catch statement.
    }//End of delay() function

    
    
    
    
    /**
     * Purpose: Entry Point to Class Android, consists of functions that makes up the 7 part UI/UX, everything is represented by these 6 methods. Also includes a JFrame and a Phidget element.
     * @param:
     * @return:
     */
    public static void main(String[] args) throws Exception {
        //Variable Declarations
        JFrameExemplar1 runGui;
        RoverThumbstick roverControl;
        
        //Clears terminal screen to ensure a clean UI/UX
        System.out.print('\u000C');
        
        //JFrame
        runGui = new JFrameExemplar1();
        
        //creating an instance of class Android
        Android android = new Android();
        
        //7 part UI/UX
        title();
        welcome();
        intro();
        explanation();
        System.out.print('\u000C');
        android.requestAction();
        thankYou();
        
        //Phidget
        roverControl = new RoverThumbstick(); 
    }//End of main
    
}//End of Class Android

/*
 * End of Program Comments
 * 
 * Notes: The horizontal Axis of the thumbstick controller may be inverted when used with the rover that wasn't ours. Our rover should have a sticker/label with our names on it.
 * 
 * Test Codes:
 * 
 * Assign this function to a variable of type double in the Main and print the variable. Enter anything in the terminal and observe.
 * public static double getUserDoubleInput(){
        double userDoubleInput = 0;
        boolean validDoubleInput = false;
        
        System.out.print("Enter a number: ");
        
        validDoubleInput = getUserInput.hasNextDouble();
        
        if (validDoubleInput){
            userDoubleInput = getUserInput.nextDouble();
            getUserInput.nextLine();
        } else {
            do {
                getUserInput.nextLine();//consumes invalid data types
                
                System.out.print("Please enter a valid input (numbers):");
                
                validDoubleInput = getUserInput.hasNextDouble();
            } while (!validDoubleInput);//End of do-while loop
            
            if (validDoubleInput){
                userDoubleInput = getUserInput.nextDouble();
                getUserInput.nextLine();
            }//End of if statement
        }//End of if-else statement
        
        return userDoubleInput;
    
 * 
 * 
 * 
 * 
 */
