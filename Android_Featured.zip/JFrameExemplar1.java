// Import Declarations
import javax.swing.JFrame; 
import javax.swing.JPanel; 
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

/**
 * Title: Android J-Frame Example with Sky and Clouds
 * 
 * Program Summary: 
 * The class JFrameExemplar1 demonstrates a basic GUI (Graphical User Interface) with a sky-themed background, clouds, and a droid image.
 *
 * Program Element List:
 * Frames, Panels, setBounds(), setLayout(), getContentPane(), setBackground(), add(), setVisible(), ExitOnClose  
 *
 * @author
 * @version
 */
public class JFrameExemplar1 {
    
    // Define Frame Objects
    JFrame myFrame;
    JPanel mainPanel;
    JLabel label1;
    JLabel droidImageLabel;
    JLabel cloudLabel1;
    JLabel cloudLabel2;
    
    /**
     * Constructor for objects of class JFrameExemplar1
     */
    public JFrameExemplar1() {
        myFrame = new JFrame("Android");
        mainPanel = new JPanel();
        label1 = new JLabel("Android");
        
        ImageIcon droidIcon = new ImageIcon("drone.png"); 
        droidImageLabel = new JLabel(droidIcon);
        
        ImageIcon scaledDroidIcon = new ImageIcon(droidIcon.getImage().getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH));
        droidImageLabel.setIcon(scaledDroidIcon);
        
        ImageIcon cloudIcon = new ImageIcon("cloud.png");
        cloudLabel1 = new JLabel(cloudIcon);
        cloudLabel2 = new JLabel(cloudIcon);
        
        
        myFrame.setLayout(new GridBagLayout());
        mainPanel.setLayout(new GridBagLayout());
        
        myFrame.setBounds(100, 100, 600, 400); 
        
        
        mainPanel.setBackground(new Color(135, 206, 235));
        
        
        label1.setFont(new Font("Arial", Font.BOLD, 24));
        label1.setForeground(Color.WHITE);
        label1.setHorizontalAlignment(JLabel.CENTER);
        
        
        GridBagConstraints gbc = new GridBagConstraints();
        
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 0.2;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets.set(10, 10, 0, 0);
        mainPanel.add(cloudLabel1, gbc);
        
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.insets.set(10, 0, 0, 10); 
        mainPanel.add(cloudLabel2, gbc);
        
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weighty = 0.2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets.set(0, 0, 0, 0); 
        mainPanel.add(label1, gbc);
        
       
        gbc.gridy = 2;
        gbc.weighty = 0.6;
        mainPanel.add(droidImageLabel, gbc);
        
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.BOTH;
        myFrame.add(mainPanel, gbc);
        
    
        JPanel greenPanel = new JPanel();
        greenPanel.setBackground(Color.GREEN);
        gbc.gridy = 1;
        gbc.weighty = 0.1;
        myFrame.add(greenPanel, gbc);
        
        
        myFrame.setVisible(true);
        
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
