import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CalculatorVisual { // implements ActionListener Removed

    JFrame frame;
    JTextField textfield;
    JButton[] numberButtons = new JButton[10];
    JButton[] functionButtons = new JButton[9];
    JButton addButton,subButton,mulButton,divButton;
    JButton decButton, equButton, delButton, clrButton, negButton;
    JPanel panel;
    
    Font myFont = new Font("Ink Free",Font.BOLD,30);
    
    double num1=0,num2=0,result=0;
    char operator;
    
    CalculatorVisual(){
        
        frame = new JFrame("CalculatorVisual");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 550);
        frame.setLayout(null);
        
        textfield = new JTextField();
        textfield.setBounds(80, 25, 300, 50);
        textfield.setFont(myFont);
        textfield.setEditable(false);
        
        addButton = new JButton("+");
        subButton = new JButton("-");
        mulButton = new JButton("*");
        divButton = new JButton("/");
        decButton = new JButton(".");
        equButton = new JButton("=");
        delButton = new JButton("Del");
        clrButton = new JButton("Clr");
        negButton = new JButton("(-)");
        
        functionButtons[0] = addButton;
        functionButtons[1] = subButton;
        functionButtons[2] = mulButton;
        functionButtons[3] = divButton;
        functionButtons[4] = decButton;
        functionButtons[5] = equButton;
        functionButtons[6] = delButton;
        functionButtons[7] = clrButton;
        functionButtons[8] = negButton;
        
        for(int i =0;i<9;i++) {
            //functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
            functionButtons[i].setFocusable(false);
        }
        
        for(int i =0;i<10;i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            //numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(myFont);
            numberButtons[i].setFocusable(false);
            numberButtons[i].setBackground(Color.CYAN);
        }
        
        negButton.setBounds(40,410,100,50);
        delButton.setBounds(150,420,100,50);
        clrButton.setBounds(260,430,100,50);
        
        panel = new JPanel();
        panel.setBounds(70, 70, 300, 300);
        panel.setLayout(new GridLayout(4,4,10,10));
        
        panel.setBackground(Color.PINK);
        frame.getContentPane().setBackground(Color.RED);
        textfield.setBackground(Color.ORANGE);
        addButton.setBackground(Color.BLUE);
        subButton.setBackground(Color.ORANGE);
        mulButton.setBackground(Color.RED);
        divButton.setBackground(Color.BLACK);
        decButton.setBackground(Color.WHITE);
        equButton.setBackground(Color.YELLOW);
        negButton.setBackground(Color.GREEN);
        delButton.setBackground(Color.PINK);
        clrButton.setBackground(Color.MAGENTA);
        

        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addButton);
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(subButton);
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(mulButton);
        panel.add(decButton);
        panel.add(numberButtons[0]);
        panel.add(equButton);
        panel.add(divButton);
        
        frame.add(panel);
        frame.add(negButton);
        frame.add(delButton);
        frame.add(clrButton);
        frame.add(textfield);
        frame.setVisible(true);
    }
    
    
    
     
    
    public static void main(String[] args) {
        
        CalculatorVisual calc = new CalculatorVisual();
    }
    
    
}





/**
 * 
 * NOTES: 
 * This Visual Version of the Calcultor Removed ALL the Actionable / Interactivity Code Leaving Only UI/UX for Simplicity
 * 
 * AKA: Removal of Action Listener Methods
 * 
 * 
 * 
 * 
 * 
 * Test Code:
 * 
 *          @Override
 *          public void actionPerformed(ActionEvent e) { //Removed
 *     
 *     
 *              This code is used to make the buttons work
 * 
 * 
 *          } // END of Method actionPerformed
 * 
 */

