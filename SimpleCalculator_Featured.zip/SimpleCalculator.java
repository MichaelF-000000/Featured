//import decalrations
import javax.swing.*;
import java.util.Scanner;
import com.phidget22.*;
/**
 * Program Title: SimpleCalculator
 *
 * Program Summary: Program Designed to assist users in calculating whatever they want to calculate, there are 5 operators that they have access to: 
 * add (+), subtract (-), multiply (*), divide (/), remainder (%). This program also has two Jframe implementations, one is a calculator interface simulating a physical calculator, another
 * contains the title to this program, we also have a phidget part which displays the answer on an LCD screen.
 * 
 * Program Elements: (1) 7 part UI/UX methods, (2) if-then-else statments, (3) switch statement, (4) the 5 arithmetic operation (static) methods, (5) do while loop, (6) 3 getUserInput methods, (7) Scanner, (8) delay method (wait()), (9) Phidget Object (displayAnswer), (10) Jframe Objects (runGui & frame)
 *
 * @authors Michael Fung, Justin Strand
 * @version BlueJ Version 5.4.1
 * Last Updated: 11/21/2024
 */
public class SimpleCalculator
{
    //Instance Fields (None)
    
    //Constructor (None)
    
    /*
     * purpose: Title method that prints an ASCII title of the program when called.
     * @param None
     * @return None
     */
    public static void title () { 
        System.out.println("  ██████  ██▓ ███▄ ▄███▓ ██▓███   ██▓    ▓█████     ▄████▄   ▄▄▄       ██▓     ▄████▄   █    ██  ██▓    ▄▄▄     ▄▄▄█████▓ ▒█████   ██▀███  ");
        System.out.println("▒██    ▒ ▓██▒▓██▒▀█▀ ██▒▓██░  ██▒▓██▒    ▓█   ▀    ▒██▀ ▀█  ▒████▄    ▓██▒    ▒██▀ ▀█   ██  ▓██▒▓██▒   ▒████▄   ▓  ██▒ ▓▒▒██▒  ██▒▓██ ▒ ██▒");
        System.out.println("░ ▓██▄   ▒██▒▓██    ▓██░▓██░ ██▓▒▒██░    ▒███      ▒▓█    ▄ ▒██  ▀█▄  ▒██░    ▒▓█    ▄ ▓██  ▒██░▒██░   ▒██  ▀█▄ ▒ ▓██░ ▒░▒██░  ██▒▓██ ░▄█ ▒");
        System.out.println("  ▒   ██▒░██░▒██    ▒██ ▒██▄█▓▒ ▒▒██░    ▒▓█  ▄    ▒▓▓▄ ▄██▒░██▄▄▄▄██ ▒██░    ▒▓▓▄ ▄██▒▓▓█  ░██░▒██░   ░██▄▄▄▄██░ ▓██▓ ░ ▒██   ██░▒██▀▀█▄  ");
        System.out.println("▒██████▒▒░██░▒██▒   ░██▒▒██▒ ░  ░░██████▒░▒████▒   ▒ ▓███▀ ░ ▓█   ▓██▒░██████▒▒ ▓███▀ ░▒▒█████▓ ░██████▒▓█   ▓██▒ ▒██▒ ░ ░ ████▓▒░░██▓ ▒██▒");
        System.out.println("▒ ▒▓▒ ▒ ░░▓  ░ ▒░   ░  ░▒▓▒░ ░  ░░ ▒░▓  ░░░ ▒░ ░   ░ ░▒ ▒  ░ ▒▒   ▓▒█░░ ▒░▓  ░░ ░▒ ▒  ░░▒▓▒ ▒ ▒ ░ ▒░▓  ░▒▒   ▓▒█░ ▒ ░░   ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░");
        System.out.println("░ ░▒  ░ ░ ▒ ░░  ░      ░░▒ ░     ░ ░ ▒  ░ ░ ░  ░     ░  ▒     ▒   ▒▒ ░░ ░ ▒  ░  ░  ▒   ░░▒░ ░ ░ ░ ░ ▒  ░ ▒   ▒▒ ░   ░      ░ ▒ ▒░   ░▒ ░ ▒░");
        System.out.println("░  ░  ░   ▒ ░░      ░   ░░         ░ ░      ░      ░          ░   ▒     ░ ░   ░         ░░░ ░ ░   ░ ░    ░   ▒    ░      ░ ░ ░ ▒    ░░   ░ ");
        System.out.println("      ░   ░         ░                ░  ░   ░  ░   ░ ░            ░  ░    ░  ░░ ░         ░         ░  ░     ░  ░            ░ ░     ░     ");
        System.out.println("                                                   ░                          ░                                                            ");
    }//End of title method
    
    
    
    
    
    /*
     * purpose: Prints the welcome message of the program
     * @param None
     * @return None
     */
    public static void welcome () {
        System.out.println("");
        System.out.println("Welcome to SimpleCalculator, here you can calculate whatever your heart desires!");
        System.out.println("Whether you're failing math class without a calcuator, or just straight up stupid, this calculator will help you with whatever you cannot solve on your own!");
    }//End of welcome method
    
    
    
    
    
    /*
     * purpose: Prints the introduction message of the program
     * @param None
     * @return None
     */
    public static void introduction () {
        System.out.println("");
        System.out.println("This is the Simple Calculator program used for all your simple calcuating needs,");
        System.out.println("from addition to subtraction, and multiplication to division, this calculator has everything you could ever need!");
        System.out.println("The Simple Calcuator has one purpose, and that is to help you calculate any math problems you're struggling with, and give you the correct answer, with minimal work!");
    }//End of introduction method
    
    
    
    
    
    /*
     * purpose: Prints the explanation message of the program
     * @param None
     * @return None
     */
    public static void explanation () {
        System.out.println("");
        System.out.println("To use the calculator, you will be directed to enter a number, an operator, and another number to use the operator on.");
        System.out.println("Then the program will output the answer on here.");

    }//End of explanation
    
    
    
    
    
    /*
     * purpose: Prints the thank you message of the program
     * @param None
     * @return None
     */
    public static void thankYou() {
        System.out.println("");
        System.out.println("Thank you for using our Simple Calculator program. Hope to see you soon.");
    }//End of thankYou
    
    
    
    
    
    /*
     * purpose: Acquires the first number of the calculation process.
     * @param None
     * @return input, the first number of the calculation
     */
    public static double getUserFirstInput () {
        Scanner getInput = new Scanner(System.in);
        double input;
        
        System.out.println("");
        System.out.print("Enter a number, can include decimal places: ");
        
        while(!getInput.hasNextDouble()){
            System.out.println("Invalid input. Please enter a number.");
            getInput.next();
            System.out.print("Enter a number: ");
        }
        
        input = getInput.nextDouble();
        System.out.println("");
        return input;
        
    }//End of getUserFirstInput
    
    
    
    
    
    /*
     * purpose: Acquires the arithmetic operator/symbol, which indicates what type of calculation the program should do.
     * @param None
     * @return inputOperator, symbol that indicates type of operation
     */
    public static String getOperatorInput () {
        Scanner getInput = new Scanner(System.in);
        boolean enteredCorrectly;
        String inputOperator;
        
        System.out.print("Enter one of the following operators: + (addition), - (subtraction), * (multiplication), / (division), % (remainder). You entered: ");
        inputOperator = getInput.nextLine();
        
        //checks if the string contains any arithmetic symbols, if it doesn't, the code in this block will run until the user's input contains one.
        if ((!inputOperator.contains("+")) && (!inputOperator.contains("-")) && (!inputOperator.contains("*")) && (!inputOperator.contains("/")) && (!inputOperator.contains("%"))) {
            do {
                System.out.println("You didn't enter a operator correctly, please try again.");
                System.out.print("You entered: ");
                getInput = new Scanner(System.in);
                inputOperator = getInput.nextLine();
            } while ((!inputOperator.contains("+")) && (!inputOperator.contains("-")) && (!inputOperator.contains("*")) && (!inputOperator.contains("/")) && (!inputOperator.contains("%")));//end of do while loop
        }//End of if statement
        
        System.out.println("");
        
        return inputOperator;
    }//End of getOperatorInput
    
    
    
    
    
    /*
     * purpose: Acquires the second number of the calculation process.
     * @param None
     * @return input, the second number of the calculation
     */
    public static double getUserSecondInput () {
        Scanner getInput = new Scanner(System.in);
        double input;
        
        System.out.print("Now enter a second number, can include decimal places: ");
        
        while(!getInput.hasNextDouble()){
            System.out.println("Invalid input. Please enter a number.");
            getInput.next();
            System.out.print("Enter a number: ");
        }//End of while loop
        
        input = getInput.nextDouble();
        System.out.println("");
        
        return input;
        
    }//End of getUserSecondInput
    
    
    
    
    
    /*
     * purpose: States the arithemtic expression that the user wants the program to calculate
     * @param None
     * @return None
     */
    public static void stateExpression(double inputOne, String operator, double inputTwo) {
        System.out.println("This is the expression you entered: " + inputOne + " " + operator + " " + inputTwo); 
    }// End of stateExpression
    
    
    
    
    
    /*
     * purpose: multiply method
     * @param double a & double b, represents the first & second number of the calculation
     * @return a * b, product of the 2 parameters
     */
    public static double multiply (double a, double b) {
        return a * b;   
    }//End of multiply method
    
    
    
    
    
    /*
     * purpose: subtraction method
     * @param double a & double b, represents the first & second number of the calculation
     * @return a - b, difference of the two params
     */
    public static double subtraction (double a, double b) {
        return a - b;
    }//End of subtraction method
    
    
    
    
    
    /*
     * purpose: addition method
     * @param double a & double b, represents the first & second number of the calculation
     * @return a + b, sum of the two params
     */
    public static double addition (double a, double b) {
        return a + b;
    }//End of addition method
    
    
    
    
    
    /*
     * purpose: division method
     * @param double a & double b, represents the first & second number of the calculation
     * @return a / b, quotient of two params
     */
    public static double division (double a, double b) {
        return a / b; 
    }//End of division method
    
    
    
    
    
    /*
     * purpose: remainder method
     * @param double a & double b, represents the first & second number of the calculation
     * @return a % b, the remainder when a is divided by b
     */
    public static double remainder (double a, double b) {
        return a % b; 
    }//End of remiander method
    
    
    
    
    
    /*
     * purpose: Catches division by zero when using the division or remainder operator.
     * @param double a, the second input will be in place of the parameter
     * @return true/false, returns true if division by zero is detected, returns false if it's not.
     */
    public static boolean divideByZero(double a) {
        
        if (a == 0) {
            return true;
        } else {
            return false;
        }//End of if-then-else statement
    
    }//End of divideByZero method
    
    
    
    
    
    /*
     * purpose: asks user if they want to repeat the program
     * @param None
     * @return confirmRepeat, a boolean, program will repeat if the boolean is true
     */
    public static boolean askForLoop() {
        boolean confirmRepeat;
        String userRepeatInput;
        Scanner getInput = new Scanner(System.in);
        System.out.print("Repeat Program? YES (y) or NO (n): ");
        userRepeatInput = getInput.nextLine();
        
        
        //Analyzing user input
        if ((userRepeatInput.equalsIgnoreCase("Y")) || (userRepeatInput.equalsIgnoreCase("YES")) || (userRepeatInput.equalsIgnoreCase("YS"))){
            confirmRepeat = true;
        } else {
            confirmRepeat = false;
        }
        
        return confirmRepeat;
    }//End of askForLoop method
    
    
    
    
    
    /*
     * purpose: calculates the result by first using the methods that gets the user's input, then comparing the arithmetic operator, then finally do the calculation and outputs the answer
     * @param: none
     * @return none
     */
    public static void calculationsAndOutput() throws Exception {
        double inputOne;
        double inputTwo;
        double answer = 0;//default value
        boolean noAnswer;
        boolean loop = false;
        String operator;
        GraphicLCDObj answerDisplay;//ONLY DISPLAYS FINAL ANSWER WHEN USER CHOOSES TO NOT REPEAT PROGRAM
        
        
        do { //start of do while loop
            noAnswer = false;
            answer = 0;
            inputOne = getUserFirstInput();//getUserInput + reiterate methods
            operator = getOperatorInput();
            inputTwo = getUserSecondInput();
        
            switch (operator) {//determining the type of calculation that needs to be done & calculations
              case "+":
                answer = addition(inputOne,inputTwo);
                break;
              case "-":
                answer = subtraction(inputOne,inputTwo);
                break;
              case "*":
                answer = multiply(inputOne,inputTwo);
                break;
              case "/":
               
                if (divideByZero(inputTwo)) {
                    System.out.println("You cannot divide by zero!");
                    noAnswer = true;
                } else {
                    answer = division(inputOne, inputTwo);
                }//End of if-else statement
                
                break;
              case "%":
                
                  if (divideByZero(inputTwo)) {
                    System.out.println("You cannot divide by zero!");
                    noAnswer = true;
                } else {
                    answer = remainder(inputOne, inputTwo);
                }//End of if-else statement
                
                break;
              default:
                noAnswer = true;//default code to run, if variable "operator" does not match with any operators above, which shouldn't happen
                break;
            }//End of switch statement
        
            stateExpression(inputOne, operator, inputTwo);
            
            if (!noAnswer){
                System.out.println("");
                System.out.println("The answer is: " + answer);//output
                System.out.println("");
                //answerDisplay = new GraphicLCDObj();//activates LCD phidget/creates new phidget object
            } else {
                System.out.println("");
                System.out.println("The expression you provided does not have an answer. Likely due to division by zero.");
                System.out.println("");
            }//End of if-else statement
            
            loop = askForLoop();//if variable loop is true, do while loop repeats
            
        
    
        } while (loop);//End of do while loop
        
        answerDisplay = new GraphicLCDObj(answer);//activates LCD phidget/creates new phidget object & displays the finish answer   
    }
    
    
    

    
    /*
     * purpose: Entry Point to Class Simple Calculator, consists of methods that makes up the 7 part UI/UX, everything is represented by these 6 methods
     * @param None
     * @return None
     */
    public static void main(String[] args) throws Exception {
        //Variable Declarations
        JFrameExemplar1 runGui = new JFrameExemplar1();
        CalculatorVisual frame = new CalculatorVisual();
        
        
        title();
        welcome();
        introduction();
        explanation();
        calculationsAndOutput();//made of methods that gets the user input & this method calculates and gives the output as well.
        thankYou();
    
    }//End of Main
}//End of Class SimpleCalculator

/*
 * End of Program Comments
 * 
 * Note: The JframeExemplar's GUI does not pop up automatically when program is launched, you have to click it open manually
 *       The phidget's display only displays the answer after user chooses to not reapeat the program
 * 
 * 
 * Test Codes:
 * 
 * This method acquires the arithmetic operator from the user.
 * 
 *  public static String getOperatorInput () {
        Scanner getInput = new Scanner(System.in);
        boolean enteredCorrectly;
        String inputOperator;
        
        System.out.print("Enter one of the following operators: + (addition), - (subtraction), * (multiplication), / (division), % (remainder). You entered: ");
        inputOperator = getInput.nextLine();
        
        //checks if the string contains any arithmetic symbols, if it doesn't, the code in this block will run until the user's input contains one.
        if ((!inputOperator.contains("+")) && (!inputOperator.contains("-")) && (!inputOperator.contains("*")) && (!inputOperator.contains("/")) && (!inputOperator.contains("%"))) {
            do {
                System.out.println("You didn't enter a operator correctly, please try again.");
                System.out.print("You entered: ");
                getInput = new Scanner(System.in);
                inputOperator = getInput.nextLine();
            } while ((!inputOperator.contains("+")) && (!inputOperator.contains("-")) && (!inputOperator.contains("*")) && (!inputOperator.contains("/")) && (!inputOperator.contains("%")));//end of do while loop
        }//End of if statement
        
        System.out.println("");
        
        return inputOperator;
    }
 * 
 * 
 * 
 * 
 * 
 */