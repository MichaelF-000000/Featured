
//Add Phidgets Library | You added a file called phidget22 when configuring your project. Import gives you access to the Phidgets library code inside that file. 
import com.phidget22.*;




/**
 * Title: Graphic LCD Display
 * 
 * Program Summary: This program is used to connect to the Graphic LCD Phidget Display for output. This program is run from the main
 * 
 * Program Element List: 
 * 
 * 
 *
 * @author (Teammates || Role):
 * @version (a version number):  
 * @date (Last Updated):
 */
public class GraphicLCDObj {
    // Instance Variables
    // Create LCD Object
    LCD lcd = new LCD();

    
    
    /**
     * Constructor for objects of class TestTest
     */
    public GraphicLCDObj(double answer) throws Exception {
        // Initialise Instance Variables
        //NONE. 
        
        
        //Open
        lcd.open(1000);
        
        //Use your Phidgets
        lcd.writeText(LCDFont.DIMENSIONS_6X12, 0, 0, "Answer: "  +answer);
        lcd.flush();
    } //END of Constructor GraphicLCDMain
    
    
    /*
    Constructor for objects of class TestTest
    
    public GraphicLCDObj() throws Exception {
        // Initialise Instance Variables
        //NONE. 
        
        
        //Open
        lcd.open(1000);
        
        //Use your Phidgets
        lcd.writeText(LCDFont.DIMENSIONS_6X12, 0, 0, "Hello, World!");
        lcd.flush();
    } //END of Constructor GraphicLCDMain
    */

    
    
    
    
    /**
     * Summary:     Main -- Primary Point of Entry to Program -- Use of Graphic LCD Screen for output
     *
     * @param       String[] args   Default parameters for Main Entry Point to Program
     * @return      NONE. 
     * 
     * Handle Exceptions | Exceptions will happen in your code from time to time. These are caused by unexpected things happening. Make sure you’ve added "throws Exception" to your main method
     *     
     */
    public static void main (String[] args) throws Exception{
        // Variable Declaraions
        
        //GraphicLCDObj displayMsgLCD = new GraphicLCDObj();
        


        
        
    } //END of Main
} // END of Class GraphicLCDMain



/*
 * 
 * NOTES: 
 * 
 * 
 * 
 * TEST CODE: 
 * 
 * 
 */
  
        
        